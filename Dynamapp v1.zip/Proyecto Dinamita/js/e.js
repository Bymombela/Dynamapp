document.addEventListener('DOMContentLoaded', function() {
    var usuarios = [];
    var Contraseñas



    var usuarioInput = document.querySelector('input[name="usuario"]');
    var passwordInput = document.querySelector('input[name="password"]');

    usuarioInput.addEventListener('input', function() {
        var usuario = this.value;
        console.log('Usuario:', usuario);
    });

    passwordInput.addEventListener('input', function() {
        var password = this.value;
        console.log('Contraseña:', password);
    });


});

/*function ing(){
    window.location.href = "index.html";
}*/

