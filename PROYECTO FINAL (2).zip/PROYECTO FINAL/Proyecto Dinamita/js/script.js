// Nodos de la red
var nodes = new vis.DataSet([
    {id: 1, label: 'Switch 1', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 2, label: 'Router 1', shape :'image', image:'https://th.bing.com/th/id/OIP.jSD3BjI__X7v5jdtG2sRrwAAAA?rs=1&pid=ImgDetMain'},
    {id: 3, label: 'Pc1',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'},
    {id: 4, label: 'Switch 2', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 5, label: 'Swicth 3', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 6, label: 'Pc2',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'},
    {id: 7, label: 'Pc3',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'}
]); 

// Conexiones entre los nodos
var edges = new vis.DataSet([
    {from: 1, to: 2},
    {from: 1, to: 3},
    {from: 2, to: 4},
    {from: 2, to: 5},
    {from: 4, to: 6},
    {from: 5, to: 7}


]);

// Crear una red
var container = document.getElementById('network');
var data = {
    nodes: nodes,
    edges: edges
};
var options = {}; // Opciones para personalizar la red
var network = new vis.Network(container, data, options);



// Obtener el botón y el contenedor de la red
var showButton = document.getElementById("showNetworkBtn");
var networkContainer = document.getElementById("networkContainer");

var networkCreated = false; // Variable para asegurarse de que solo se cree la red una vez

// Añadir evento de clic al botón
showButton.addEventListener("click", function() {
    // Cambiar entre "block" y "none"
    if (networkContainer.style.display === "none" || networkContainer.style.display === "") {
        networkContainer.style.display = "block"; // Mostrar el contenedor
         // Crear la red siempre que se muestre el contenedor
        showButton.textContent = "Ocultar red"; // Cambiar texto del botón
    } else {
        networkContainer.style.display = "none"; // Ocultar el contenedor
        showButton.textContent = "Mostrar red"; // Cambiar texto del botón
    }
});

