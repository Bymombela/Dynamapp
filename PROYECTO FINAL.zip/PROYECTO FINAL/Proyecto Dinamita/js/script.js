// Nodos de la red
var nodes = new vis.DataSet([
    {id: 1, label: 'Switch 1', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 2, label: 'Router 1', shape :'image', image:'https://th.bing.com/th/id/OIP.jSD3BjI__X7v5jdtG2sRrwAAAA?rs=1&pid=ImgDetMain'},
    {id: 3, label: 'Pc1',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'},
    {id: 4, label: 'Switch 2', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 5, label: 'Swicth 3', shape :'image', image:'https://images.freeimages.com/clg/images/39/398231/network-switch-clip-art_f.jpg'},
    {id: 6, label: 'Pc2',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'},
    {id: 7, label: 'Pc3',      shape :'image', image:'https://static.vecteezy.com/system/resources/previews/006/895/992/non_2x/computer-laptop-cartoon-illustration-icon-with-empty-lcd-panel-vector.jpg'}
]); 

// Conexiones entre los nodos
var edges = new vis.DataSet([
    {from: 1, to: 2},
    {from: 1, to: 3},
    {from: 2, to: 4},
    {from: 2, to: 5},
    {from: 4, to: 6},
    {from: 5, to: 7}


]);

// Crear una red
var container = document.getElementById('network');
var data = {
    nodes: nodes,
    edges: edges
};
var options = {}; // Opciones para personalizar la red
var network = new vis.Network(container, data, options);

var showButton = document.getElementById("showNetworkBtn");
var networkContainer = document.getElementById("networkContainer");

        showButton.addEventListener("click", function() {
            networkContainer.style.display = "block"; 
        });
